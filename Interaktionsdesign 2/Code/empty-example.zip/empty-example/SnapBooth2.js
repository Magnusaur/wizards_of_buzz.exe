var loaded;
var Img = [];
var xPs = 0;
var yPs = 0;
var c;
var counter = 0;
var video;
var cycleNum = 256;

function setup() {
  c = createCanvas(windowWidth/3, windowHeight/2);
  frameRate(30);
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();

  takeSnap(counter);
}

function takeSnap(i) {
  let n = frameCount % cycleNum;
    if (n == 0) {
      saveCanvas(c, 'prototype','jpg');
      loaded = loadImage('prototype('+i+')','jpg');
      // loaded = loadImage('puffin.jpg');
    }

  Img.push(new Imgs(loaded));
}

function draw() {
  // Img[0].display(0, 0)

  image(video, 0, 0, width, height);

  let x = windowWidth/5
  let y = windowHeight/4
  for(let i = 0; i < Img.length; i++) {
    Img[i].display(xPs, yPs, x, y);
  }
  if (xPs > width) {
    xPs = 0;
    yPs += y;
  } else {
    xPs += x
  }

  counter++
  takeSnap(counter)
}



class Imgs {
  constructor(loaded) {
    this.loaded = loaded;
  }

  display(xPs, yPs, x, y) {
    this.xPs = xPs;
    this.yPs = yPs;
    this.x = x;
    this.y = y;

    image(loaded, this.xPs, this.yPs, this.x, this.y); //Every image drawn will show the capture feed
  }
}
